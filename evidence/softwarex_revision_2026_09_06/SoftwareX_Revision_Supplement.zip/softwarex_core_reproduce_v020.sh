#!/usr/bin/env bash
set -euo pipefail

# One-command core reproduction for SoftwareX revision SOFTX-D-26-00862.
# This wrapper does not modify the Metriplane v0.2.0 tag or repository history.
# It clones the immutable tag into a temporary directory, installs the declared
# runtime package, runs the camera-free replay + Atlas path, verifies the bundle,
# runs the generated presence-based check, asserts the expected core results,
# and exits 0 only if every core gate passes.

EXPECTED_COMMIT="8e35ed5bb20837f7dc46354777407b848d7ce17a"
ROOT="$(mktemp -d "${TMPDIR:-/tmp}/metriplane-softwarex-core-reproduction.XXXXXX")"
REPO="$ROOT/metriplane"
RUNS="$ROOT/runs"
ATLAS="$ROOT/atlas"


git clone --branch v0.2.0 --depth 1 https://github.com/Miko997/metriplane.git "$REPO"
cd "$REPO"

ACTUAL_COMMIT="$(git rev-parse HEAD)"
test "$ACTUAL_COMMIT" = "$EXPECTED_COMMIT"
test -z "$(git status --porcelain)"

python3 -m venv .venv
# shellcheck disable=SC1091
source .venv/bin/activate

python -m pip install --upgrade pip
python -m pip install -e .

python -m metriplane.cli doctor

RUNS="$RUNS" ./tools/mp.sh deterministic-replay datasets/demo/session_001.jsonl

metriplane atlas validate-pack configs/domain_packs/assembly_cell

metriplane atlas run \
  --session-jsonl datasets/demo/atlas/assembly_cell_missing_tool.jsonl \
  --pack configs/domain_packs/assembly_cell \
  --out "$ATLAS" \
  --run-id softwarex_core_reproduction \
  --overwrite

metriplane atlas bundle verify \
  "$ATLAS/evidence_bundles/INC-0001.zip"

metriplane atlas test \
  "$ATLAS/regression_tests/INC-0001.yaml" \
  --json > "$ROOT/regression_result.json"

python - "$RUNS/demo-evidence/replay_determinism.csv" "$ATLAS/atlas_manifest.json" "$ROOT/regression_result.json" <<'PY'
import csv
import json
import sys
from pathlib import Path

replay_path = Path(sys.argv[1])
manifest_path = Path(sys.argv[2])
regression_path = Path(sys.argv[3])

if not replay_path.is_file():
    raise SystemExit(f"missing replay result: {replay_path}")

rows = list(csv.DictReader(replay_path.open(encoding="utf-8")))
if len(rows) != 1:
    raise SystemExit(f"unexpected replay summary row count: {len(rows)}")

row = rows[0]
# Preserve compatibility with the frozen v0.2.0 summary field names.
expected_numeric = {
    "frames_compared": 24,
    "object_pairs_compared": 72,
}
for key, expected in expected_numeric.items():
    if int(float(row[key])) != expected:
        raise SystemExit(f"{key}: expected {expected}, got {row[key]}")

for key in ("mean_pos_diff_cm", "max_pos_diff_cm"):
    if float(row[key]) != 0.0:
        raise SystemExit(f"{key}: expected 0.0, got {row[key]}")

# Historical field; v0.2.0 implementation counts differing matched-object zone
# fields, not typed Atlas event-ledger mismatches.
if int(float(row["event_mismatch_count"])) != 0:
    raise SystemExit(
        "matched-object zone-field mismatch counter: expected 0, "
        f"got {row['event_mismatch_count']}"
    )

manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
expected_manifest = {
    "frame_count": 5,
    "event_count": 6,
    "deviation_count": 1,
    "incident_count": 1,
}
for key, expected in expected_manifest.items():
    if manifest.get(key) != expected:
        raise SystemExit(f"{key}: expected {expected}, got {manifest.get(key)}")

regression = json.loads(regression_path.read_text(encoding="utf-8"))
if regression.get("pass") is not True:
    raise SystemExit(f"generated check failed: {regression}")

print(json.dumps({
    "schema_version": "metriplane.softwarex.core_reproduction.v1",
    "artifact_commit": "8e35ed5bb20837f7dc46354777407b848d7ce17a",
    "replay": {
        "frames": 24,
        "matched_object_pairs": 72,
        "mean_pos_diff_cm": 0.0,
        "max_pos_diff_cm": 0.0,
        "matched_object_zone_field_mismatches": 0
    },
    "atlas": expected_manifest,
    "bundle_verification": "PASS",
    "generated_presence_based_check": "PASS",
    "overall": "PASS"
}, indent=2))
PY

test -z "$(git status --porcelain)"

echo
echo "SOFTWAREX CORE REPRODUCTION: PASS"
echo "commit=$ACTUAL_COMMIT"
echo "temporary_root=$ROOT"
