SoftwareX SOFTX-D-26-00862 - revision supplementary material

Scope and terminology
---------------------
This package contains revision-only characterization of the unchanged Metriplane
v0.2.0 artifact and a one-command core reproduction wrapper. It does not modify
or replace the original author evidence archived with v0.2.0.
Frozen artifact commit: 8e35ed5bb20837f7dc46354777407b848d7ce17a

"Cell Truth Report" is a project-defined artifact name for a report derived from
accepted state and configured rules. It does not denote independently established
physical ground truth. The archived identifier missing_tool_caused_delay is a
configured incident label; it does not establish that the missing tool caused the
observed delay. These qualifications also apply when reading the unchanged report
and incident artifacts supplied here.

Files
-----
- SoftwareX_revision_evidence_2026-08-30.zip
  Original control/no-incident and intentionally failing expected-event evidence,
  preserved byte-for-byte from the supplied revision package.
- SoftwareX_revision_evidence_2026-08-30.zip.sha256
- softwarex_core_reproduce_v020.sh
  Core reproduction wrapper; each invocation uses a new temporary root.
- softwarex_core_reproduce_v020.sh.sha256
- core_reproduction_2026-09-06/
  Recorded execution of the corrected wrapper, including command, environment,
  log, exit code and generated outputs. Consult execution.json for the outcome.

One-command core reproduction
-----------------------------
Prerequisites: Bash, Git, Python 3.12 or newer with venv/pip support, network access
to GitHub and the Python package index, and writable temporary storage. This is a
camera-free, CPU-only path. Run from the directory containing this README in a
shell with the Metriplane environment overrides unset (in particular RUNS,
METRIPLANE_REPO_ROOT, METRIPLANE_VENV and METRIPLANE_EVIDENCE_OUT):

    bash softwarex_core_reproduce_v020.sh

The wrapper clones v0.2.0, verifies its exact commit and initially clean checkout,
creates a virtual environment, installs the declared runtime dependencies, and
runs doctor, fixed-step replay comparison, assembly-cell pack validation, the
incident scenario, bundle verification and the generated presence-based check.
It asserts the expected replay counts and position/zone-field results, five input
frames, six events, one deviation and one incident. Exit 0 and the final
"SOFTWAREX CORE REPRODUCTION: PASS" line indicate that these gates passed. The
printed temporary_root identifies the retained checkout and outputs.

The unchanged v0.2.0 replay helper uses /tmp/out1.jsonl, /tmp/out2.jsonl and
/tmp/replay_determinism.csv internally. Run one reproduction at a time and ensure
these paths do not contain data to retain. The new wrapper root itself is unique
and is not deleted. The core route does not run the complete test suite. The two
full-suite failures reported by the external macOS reproduction remain disclosed
in the manuscript; they are not gates of this bounded core route.

Reproducing the supplied control and expected-failure cases
---------------------------------------------------------
First complete the core command above. Set CORE_ROOT to its printed temporary_root
(the example below is a placeholder), then extract the original evidence archive
from the directory containing this README. The unzip command requires unzip.
Use a fresh extraction location so that the supplied records are not overwritten.

    CORE_ROOT=/absolute/path/printed/as/temporary_root
    source "$CORE_ROOT/metriplane/.venv/bin/activate"
    unzip SoftwareX_revision_evidence_2026-08-30.zip
    cd SoftwareX_revision_evidence_2026-08-30
    CONTROL_ROOT="$(mktemp -d "${TMPDIR:-/tmp}/softwarex-control.XXXXXX")"
    metriplane atlas run \
      --session-jsonl "$PWD/control/assembly_cell_control_tool_present.jsonl" \
      --pack "$CORE_ROOT/metriplane/configs/domain_packs/assembly_cell" \
      --out "$CONTROL_ROOT/run" \
      --run-id softwarex_revision_control_tool_present

Inspect "$CONTROL_ROOT/run/atlas_manifest.json": expected event_count=4,
deviation_count=0 and incident_count=0. The required torque driver is present at
the 20 s record where the relevant step is evaluated; continuous presence is not
claimed. The newly generated run is separate from the supplied control records.

From the same extracted evidence directory, run:

    metriplane atlas test specs/baseline_presence_check.yaml --json
    metriplane atlas test specs/perturbed_expected_failure.yaml --json

The baseline must report pass=true and exit 0. The perturbed specification requires
an intentionally absent event; it must report pass=false and exit 4. That failure
is expected. These cases characterize the supplied configuration and presence-based
oracle; they do not establish event-order, timing, duration or extra-event checks.

Checksum verification
---------------------
The two outer .sha256 files use relative filenames; verify from this directory:

    sha256sum -c SoftwareX_revision_evidence_2026-08-30.zip.sha256
    sha256sum -c softwarex_core_reproduce_v020.sh.sha256

On systems without sha256sum, use "shasum -a 256 -c" instead. The original evidence
archive includes its own SHA256SUMS.txt; verify it from its extracted root. The
core_reproduction_2026-09-06 directory likewise includes SHA256SUMS.txt for the
recorded execution and outputs.
