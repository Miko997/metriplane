# Incident Report

Formal artifact: `Cell Truth Report`.

This report summarizes one recorded run: a saved sequence of object positions and timestamps from a bounded workcell.

## What happened

- Metriplane reviewed 3.7 s of recorded activity.
- It recorded 4 events and grouped them into 1 incident.
- An event is one observed change, such as an object arriving or a required tool being absent.
- An incident groups related events that need review because an expected process condition was not met.
- Incident `INC-0001` (warning): robot tcp 1 missing during Cube in target planar region requires robot TCP. Cube in target planar region requires robot TCP waited because robot tcp 1 was absent.
- Suggested follow-up: Add a required-tool staging check. INC-0001 shows a required asset was absent while a process step waited. Add a visible pre-step tool/material check.

## Why it was flagged

Process rules describe the expected steps, required objects and locations, and allowed waiting times. Metriplane flags a deviation when the recorded run does not meet one of those rules.

| reason | severity | expected step | object | supporting event records |
|---|---|---|---|---|
| missing required asset (`missing_required_asset`) | warning | `cube_target_requires_tcp` | `robot_tcp_1` | `evt_0001`, `evt_0002` |

## When it happened

The times below are measured from the start of the recorded run.

| time | what was observed | object | technical event record |
|---:|---|---|---|
| 3.3 s | robot_tcp_1 was not present for Cube in target planar region requires robot TCP. | `robot_tcp_1` | `evt_0001` / `required_asset_missing` |
| 3.5 s | Cube in target planar region requires robot TCP waited 0.2 s for robot_tcp_1. | `robot_tcp_1` | `evt_0002` / `step_delayed` |
| 3.5 s | Restored Panda TCP (planar required tool) was present for Cube in target planar region requires robot TCP. | `robot_tcp_1` | `evt_0003` / `required_asset_present` |
| 3.5 s | Cube in target planar region requires robot TCP completed. | `robot_tcp_1` | `evt_0004` / `step_completed` |

## Evidence that was saved

An evidence bundle is a checksummed ZIP that keeps the incident report and supporting records together so another person can verify what was reviewed.
- Evidence bundle for `INC-0001`: `evidence_bundles/INC-0001.zip`
- Event records: `physical_event_log.jsonl`
- Incident records: `incidents.jsonl`
- Supporting recorded state: `state_segment.jsonl`
- Formal Cell Truth Report: `cell_truth_report.html`

## Repeatable check that was generated

A regression check is a generated test that replays the saved incident and checks that the expected events and incident still appear within declared timing tolerances.

Deterministic replay uses the saved inputs and recorded time sequence instead of live timing, so repeated evaluations can be compared consistently.
- Repeatable check for `INC-0001`: `regression_tests/INC-0001.yaml`

## External fixture provenance

- Fixture: `maniskill-pickcube-episode-0-planar-incident-v1`.
- Contract: `metriplane.external_source_contract.v1` / `metriplane.atlas.complete_snapshot.v1`.
- Source: `ManiSkill Demonstrations` at revision `dataset_revision:d674485bbffdd533914e52d272fdda34c0515608`.
- Adapter: `org.metriplane.maniskill_pickcube` version `1.0.0` at commit `95d1134d9fb9273318c552c507952f1c5c26877e`.
- Full conversion provenance: `external_source_provenance.json` (SHA-256 `a787372871245c32e8715df7ac58d18af72ec15cd957c20a5783dd6dd9d792b0`).
- This identifies the supplied normalized fixture and its conversion; the incident result still comes from the recorded normalized state and the supplied process rules.

## Limits of this result

- This result is derived from recorded normalized planar object state supplied for evaluation, not a fresh interpretation of raw sensor data.
- It depends on the object identities, state, zone assignments, and process rules supplied for this run.
- It does not establish correctness, calibration, physical accuracy, or simulator realism of the upstream state.
- It is not a certified safety or quality decision and does not control machinery.
- It does not prove root cause; suggested follow-ups require before-and-after validation.
