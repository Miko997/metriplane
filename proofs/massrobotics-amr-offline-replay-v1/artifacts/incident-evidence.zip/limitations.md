# Limitations

- This result is derived from recorded normalized planar object state supplied for evaluation, not a fresh interpretation of raw sensor data.
- It depends on the object identities, state, zone assignments, and process rules supplied for this run.
- It does not establish correctness, calibration, physical accuracy, or simulator realism of the upstream state.
- It is not a certified safety or quality decision and does not control machinery.
